### Le blog 

Réaliser un blog avec les pages suivantes:

Une page d'accueil qui reprend les différents articles postés avec:
-leur titre qui est un lien permettant d'accéder au détail de l'article
-le début du contenu de l'article limité à 100 caractères
-le nom de l'auteur et la date de publication

Une page de détail de l'article avec:
-le titre
-le contenu
-les commentaires associés
-un fomulaire pour ajouter un commentaire avec pseudo et contenu

Un espace d'administration sera également à créer pour
-ajouter un article
-modifier un article existant
-supprimer un article existant

Chacune des pages aura un header et un footer qui se retrouvera sur l'ensemble des pages
Le choix du design et du thème sont libres, laisser parler votre imagination